﻿namespace ST.Models
{
    public enum RoomStatus
    {
        Active,
        Closed,
        Removed
    }
}
