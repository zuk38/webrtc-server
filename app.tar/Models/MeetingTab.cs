﻿namespace ST.Models
{
  public enum MeetingTab
  {
    WhiteBoard,
    ScreeSharing,
    Presentation,
    Video,
    Image,
    Link
  }
}