﻿namespace ST.Models
{
  public enum FileType
  {
    Pdf,
    Video,
    Image,
    Office,
    Model,
    Other
  }
}