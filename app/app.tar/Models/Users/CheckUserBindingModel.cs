﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ST.Web.Models.Users
{
  public class CheckUserBindingModel
  {
    public string Email { get; set; }
  }
}